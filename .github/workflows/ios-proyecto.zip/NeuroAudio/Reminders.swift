import Foundation
import UserNotifications

/// Recordatorios diarios locales (sin internet).
enum Reminders {
    static func schedule(_ json: String) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: (1...10).map { "neuro.\($0)" })
        guard let data = json.data(using: .utf8),
              let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { return }
        for o in arr {
            guard let id = (o["id"] as? NSNumber)?.intValue,
                  let h = (o["h"] as? NSNumber)?.intValue,
                  let m = (o["m"] as? NSNumber)?.intValue else { continue }
            let content = UNMutableNotificationContent()
            content.title = (o["title"] as? String) ?? "Neuro-Audio"
            content.body = (o["text"] as? String) ?? ""
            content.sound = .default
            var dc = DateComponents()
            dc.hour = h
            dc.minute = m
            let trigger = UNCalendarNotificationTrigger(dateMatching: dc, repeats: true)
            center.add(UNNotificationRequest(identifier: "neuro.\(id)", content: content, trigger: trigger))
        }
    }
}
