import AVFoundation
import MediaPlayer

/// Reproduce las pistas en bucle sin cortes, sigue con la pantalla bloqueada
/// (modo de fondo "audio") y se detiene sola con desvanecimiento al cumplir el tiempo.
final class AudioEngine {
    static let shared = AudioEngine()

    private var player: AVAudioPlayer?
    private var timer: Timer?
    private var startDate = Date()
    private var target: TimeInterval = 900
    private var fade: TimeInterval = 60
    private var baseVol: Float = 0.5
    private var meta = ""
    private var lastElapsed: TimeInterval = 0

    private(set) var playing = false
    private(set) var completed = false
    var onChange: (() -> Void)?

    var elapsed: TimeInterval { playing ? Date().timeIntervalSince(startDate) : lastElapsed }

    private init() {
        let cc = MPRemoteCommandCenter.shared()
        cc.pauseCommand.addTarget { [weak self] _ in self?.stop(completed: false); return .success }
        cc.stopCommand.addTarget { [weak self] _ in self?.stop(completed: false); return .success }
        cc.togglePlayPauseCommand.addTarget { [weak self] _ in self?.stop(completed: false); return .success }
    }

    func play(file: String, seconds: Double, volume: Float, title: String, meta: String, fade: Double) {
        if playing { stop(completed: false) }
        let url = Bundle.main.bundleURL.appendingPathComponent(file)
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [])
            try session.setActive(true)
            let p = try AVAudioPlayer(contentsOf: url)
            p.numberOfLoops = -1
            p.volume = 0
            p.prepareToPlay()
            p.play()
            player = p
        } catch {
            playing = false
            completed = false
            onChange?()
            return
        }
        self.target = max(1, seconds)
        self.fade = min(max(3, fade), self.target / 2)
        self.baseVol = max(0, min(1, volume))
        self.meta = meta
        playing = true
        completed = false
        lastElapsed = 0
        startDate = Date()
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: title,
            MPMediaItemPropertyArtist: "Neuro-Audio",
            MPMediaItemPropertyPlaybackDuration: self.target,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: 0.0,
            MPNowPlayingInfoPropertyPlaybackRate: 1.0
        ]
        timer?.invalidate()
        let t = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in self?.tick() }
        RunLoop.main.add(t, forMode: .common)
        timer = t
        onChange?()
    }

    private func tick() {
        guard let p = player, playing else { return }
        let el = Date().timeIntervalSince(startDate)
        let left = target - el
        if left <= 0 {
            stop(completed: true)
            return
        }
        if el < 3 {
            p.volume = baseVol * Float(el / 3)
        } else if left < fade {
            p.volume = max(0, baseVol * Float(left / fade))
        } else {
            p.volume = baseVol
        }
    }

    func setVolume(_ v: Float) {
        baseVol = max(0, min(1, v))
    }

    func stop(completed: Bool) {
        if playing { lastElapsed = Date().timeIntervalSince(startDate) }
        timer?.invalidate()
        timer = nil
        player?.stop()
        player = nil
        if completed && !meta.isEmpty {
            UserDefaults.standard.set(meta, forKey: "done")
        }
        self.completed = completed
        playing = false
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        onChange?()
    }
}
