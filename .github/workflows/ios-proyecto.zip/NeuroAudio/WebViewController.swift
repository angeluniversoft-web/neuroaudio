import UIKit
import WebKit
import UserNotifications

final class WebViewController: UIViewController, WKScriptMessageHandler, WKUIDelegate, WKNavigationDelegate {

    private var web: WKWebView!
    private var statusTimer: Timer?

    /// Puente con la interfaz web: expone el mismo objeto que usa la versión Android.
    private static let shim = """
    (function(){
      window.__ns={playing:false,completed:false,elapsed:0}; window.__nd=""; window.__playAt=0;
      function send(o){ try{ window.webkit.messageHandlers.bridge.postMessage(o); }catch(e){} }
      window.AndroidBridge={
        isNative:function(){ return true; },
        play:function(file,sec,vol,title,meta,fade){ window.__playAt=Date.now(); window.__ns={playing:true,completed:false,elapsed:0};
          send({cmd:"play",file:file,seconds:sec,volume:vol,title:title,meta:meta,fade:fade}); },
        stop:function(){ window.__ns.playing=false; window.__playAt=0; send({cmd:"stop"}); },
        setVolume:function(v){ send({cmd:"volume",value:v}); },
        getStatus:function(){ if(Date.now()-window.__playAt<1500) return JSON.stringify({playing:true,completed:false,elapsed:0});
          return JSON.stringify(window.__ns); },
        consumeDone:function(){ var d=window.__nd||""; window.__nd=""; if(d) send({cmd:"clearDone"}); return d; },
        setReminders:function(j){ send({cmd:"reminders",json:j}); },
        saveFile:function(name,content){ send({cmd:"save",name:name,content:content}); return ""; }
      };
    })();
    """

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func loadView() {
        let cfg = WKWebViewConfiguration()
        let ucc = WKUserContentController()
        ucc.add(self, name: "bridge")
        ucc.addUserScript(WKUserScript(source: Self.shim, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        cfg.userContentController = ucc
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.websiteDataStore = .default()

        web = WKWebView(frame: .zero, configuration: cfg)
        web.uiDelegate = self
        web.navigationDelegate = self
        web.isOpaque = false
        let bg = UIColor(red: 0x15 / 255.0, green: 0x1A / 255.0, blue: 0x2C / 255.0, alpha: 1)
        web.backgroundColor = bg
        web.scrollView.backgroundColor = bg
        web.scrollView.contentInsetAdjustmentBehavior = .never
        view = web
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        let www = Bundle.main.bundleURL.appendingPathComponent("www")
        web.loadFileURL(www.appendingPathComponent("index.html"), allowingReadAccessTo: www)

        AudioEngine.shared.onChange = { [weak self] in self?.pushStatus() }
        let t = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in self?.pushStatus() }
        RunLoop.main.add(t, forMode: .common)
        statusTimer = t

        NotificationCenter.default.addObserver(forName: UIApplication.didBecomeActiveNotification,
                                               object: nil, queue: .main) { [weak self] _ in
            self?.pushStatus()
            self?.web.evaluateJavaScript("typeof processNativeDone==='function' && processNativeDone(); typeof render==='function' && render();", completionHandler: nil)
        }
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    private func jsString(_ s: String) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: [s], options: []),
              let arr = String(data: data, encoding: .utf8) else { return "\"\"" }
        return String(arr.dropFirst().dropLast())
    }

    private func pushStatus() {
        guard web != nil else { return }
        let a = AudioEngine.shared
        let done = UserDefaults.standard.string(forKey: "done") ?? ""
        let js = "window.__ns={playing:\(a.playing),completed:\(a.completed),elapsed:\(a.elapsed)};window.__nd=\(jsString(done));"
        web.evaluateJavaScript(js, completionHandler: nil)
    }

    // MARK: mensajes desde JavaScript
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let o = message.body as? [String: Any], let cmd = o["cmd"] as? String else { return }
        switch cmd {
        case "play":
            AudioEngine.shared.play(file: (o["file"] as? String) ?? "",
                                    seconds: (o["seconds"] as? NSNumber)?.doubleValue ?? 900,
                                    volume: (o["volume"] as? NSNumber)?.floatValue ?? 0.5,
                                    title: (o["title"] as? String) ?? "Sesión",
                                    meta: (o["meta"] as? String) ?? "",
                                    fade: (o["fade"] as? NSNumber)?.doubleValue ?? 60)
        case "stop":
            AudioEngine.shared.stop(completed: false)
        case "volume":
            AudioEngine.shared.setVolume((o["value"] as? NSNumber)?.floatValue ?? 0.5)
        case "clearDone":
            UserDefaults.standard.removeObject(forKey: "done")
        case "reminders":
            Reminders.schedule((o["json"] as? String) ?? "[]")
        case "save":
            share(name: (o["name"] as? String) ?? "archivo.txt", content: (o["content"] as? String) ?? "")
        default:
            break
        }
    }

    private func share(name: String, content: String) {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do {
            try Data(content.utf8).write(to: url, options: .atomic)
        } catch { return }
        let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = view
        present(vc, animated: true)
    }

    // MARK: alert / confirm de JavaScript
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(a, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Cancelar", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "Aceptar", style: .default) { _ in completionHandler(true) })
        present(a, animated: true)
    }

    // Enlaces externos se abren en Safari
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url, url.scheme == "http" || url.scheme == "https",
           navigationAction.navigationType == .linkActivated {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }
}
